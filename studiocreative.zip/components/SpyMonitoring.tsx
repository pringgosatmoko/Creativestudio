
export const SpyMonitoring = () => null;
